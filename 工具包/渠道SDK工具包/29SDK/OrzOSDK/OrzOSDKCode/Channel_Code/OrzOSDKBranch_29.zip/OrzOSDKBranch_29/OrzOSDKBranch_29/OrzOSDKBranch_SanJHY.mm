

#import "OrzOSDKBranch_SanJHY.h"

@implementation OrzOSDKBranch_SanJHY


-(NSString *)getOrzOSDKChannelSdkVersion{
    return @"1.0.2";
}

-(void)doOrzOSDKChannelInit{
    NSLog(@"OrzOSDKBranch_29 doChannelInit  !");
    NSDictionary *dict = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"OrzOSDKParams"];
    NSDictionary *channel_config = [dict objectForKey:@"ChannelParams"];
    
    self.Appid_29 = [[NSString alloc] initWithFormat:@"%@", [channel_config objectForKey:@"channel_29_Appid"]];
    self.GameKey_29 = [[NSString alloc] initWithFormat:@"%@", [channel_config objectForKey:@"channel_29_GameKey"]];
    self.channelId_29 = [[NSString alloc] initWithFormat:@"%@", [channel_config objectForKey:@"channel_29_channelId"]];
    
    NSLog(@"appid_29 = %@", self.Appid_29);
    NSLog(@"miyaoKey_29 = %@", self.GameKey_29);
    NSLog(@"channelId_29 = %@", self.channelId_29);
    
//    [[TNSDK sharedManager]initSDKAppId:self.appid_29 andAppSecret:self.secret_29 andIg:self.igvaAPP_29];
    
    [LTSDK setIsShowParameterLog:YES];
    [LTSDK lt_initWithPlayId:self.Appid_29 withPlayKey:self.GameKey_29 withCanal:self.channelId_29 completion:^(BOOL success, NSString *info) {
        NSLog(@"%@", info);
        if (success) {
            [self.delegate channel_initOrzOSDKSuccess:@{@"code":@"1",@"msg":@"success"}];
        }else{
            [self.delegate channel_initOrzOSDKFail:@{@"code":@"-1",@"msg":@"failed"}];
        }
    }];

    
   // [self.delegate channel_initOrzOSDKSuccess:@{@"code":@"1",@"msg":@"success"}];
    
}

-(void)doOrzOSDKChannelLogin{
    
    NSLog(@"OrzOSDKBranch_29 doChannelLogin");
    
    [LTSDK lt_shareInstance].ltDelegate = self;
    [[LTSDK lt_shareInstance] lt_login];
    
    
}

-(void)doOrzOSDKChannelSwitchAccount{
    NSLog(@"OrzOSDKBranch_29 doChannelSwitchAccount");
    [self.delegate channel_logoutOrzOSDKSuccess:@{@"code":@"1",@"msg":@"switch account success"}];
}


-(void)doOrzOSDKChannelLogout{
    NSLog(@"OrzOSDKBranch_29 doChannelChannelLogout");
    [self.delegate channel_logoutOrzOSDKSuccess:@{@"code":@"1",@"msg":@"logout success"}];
}

-(void)doChannelshowOrzOSDKGameCenter{
    NSLog(@"OrzOSDKBranch_29 doChannelshowGameCenter");
    
}

-(void)doChannelshowOrzOSDKFloatView{
    NSLog(@"OrzOSDKBranch_29 doChannelshowFloatView");
    
}

-(void)doChannelhideOrzOSDKFloatView{
    NSLog(@"OrzOSDKBranch_29 doChannelhideFloatView");
}

-(void)doOrzOSDKChannelRegcharg:(NSDictionary *)params{
    NSLog(@"OrzOSDKBranch_29 doChannelRegcharg");
    int flag = 0;
    if([[OrzOSDKUtils getSharedInstance] getOrzOSDKInfoPlist_Landscape] == YES){
        flag = 1;
    }else{
        flag = 0;
    }
    NSLog(@"flag = %d", flag);
    
    [LTSDK lt_productWithProductId:[params objectForKey:OrzOSDK_IOS_PRODUCT_ID] roleId:self.roleid serverId:self.serverid cpInfo:[params objectForKey:OrzOSDK_IOS_ORDERID]];
    


}

- (void)lt_loginResultResponse:(NSDictionary *)response {
    NSLog(@"\nlogin = %@", response);
    
    
    [LTSDK lt_getUidWithResult:^(NSDictionary * result) {
        NSLog(@"\nresult = %@", result);
        [self.delegate channel_loginOrzOSDKSuccess:@{@"channel_uid":@"",
                                                     @"channel_username":@"",
                                                     @"channel_token":response[@"token"],
                                                     @"channel_deviceid":@"29Sdk"}];
    }];
}

- (void)lt_iapResultResponse:(NSDictionary *)response {
    NSLog(@"\niap = %@", response);
    [self.delegate channel_RegchargOrzOSDKSuccess:@{@"code":@"0",@"msg":@"支付完成"}];
}

-(void)doOrzOSDKChannelRealNameRegister:(int)flag{
    NSLog(@"OrzOSDKBranch_29 doChannelRealNameRegister");
    
}

-(void)doOrzOSDKChannelSendGameData:(NSString *)dataPoint data:(NSDictionary *)data{
    self.serverid = [[NSString alloc] initWithFormat:@"%@", [data objectForKey:OrzOSDK_SERVER_ID]];
    self.roleid = [[NSString alloc] initWithFormat:@"%@", [data objectForKey:OrzOSDK_ROLE_ID]];
    
    [LTSDK lt_upGameInfoWithRoleId:self.roleid roleName:[data objectForKey:OrzOSDK_ROLE_NAME] roleLevel:[data objectForKey:OrzOSDK_ROLE_LEVEL] serverId:[data objectForKey:OrzOSDK_SERVER_ID] serverName:[data objectForKey:OrzOSDK_SERVER_NAME]];
}

-(BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions{
    return TRUE;
}

- (void)applicationWillResignActive:(UIApplication *)application{
    
}
- (void)applicationDidEnterBackground:(UIApplication *)application{
    
}
- (void)applicationWillEnterForeground:(UIApplication *)application{
    
}
- (void)applicationDidBecomeActive:(UIApplication *)application{
    
}
- (void)applicationWillTerminate:(UIApplication *)application{
    
}

-(BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url{
    return TRUE;
}

-(BOOL)application:(UIApplication *)application openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options{
    return TRUE;
}

-(BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation{
    return TRUE;
}

-(BOOL)application:(UIApplication *)application continueUserActivity:(NSUserActivity *)userActivity restorationHandler:(void(^)(NSArray * __nullable restorableObjects))restorationHandler{
    return TRUE;
}


@end
