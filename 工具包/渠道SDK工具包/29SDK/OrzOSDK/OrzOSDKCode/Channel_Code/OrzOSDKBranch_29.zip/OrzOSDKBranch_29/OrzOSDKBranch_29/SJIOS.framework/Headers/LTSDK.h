//
//  NGSDK.h
//  copySDK
//
//  Created by Mingmin zhong on 2018/5/5.
//  Copyright © 2018年 Mingmin zhong. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol LTSDKDelegate <NSObject>
@optional

/**
 登录回调
 @param response {
                         token :@""
                            }
 */
- (void)lt_loginResultResponse:(NSDictionary *)response;

/**
支付回调
 @param response {
                             info = "";// 失败才会有提示
                             oId = "";// 订单 id
                             pId = "";// 产品 id
                             success = 0;// 是否支付成功
                             }
 */
- (void)lt_iapResultResponse:(NSDictionary *)response;
@end

typedef void(^completionBlock)(BOOL success, NSString *info);
typedef void(^resultBlock)(id result);

@interface LTSDK : NSObject

@property (nonatomic, weak) id<LTSDKDelegate> ltDelegate;/**< 回调代理 */

+ (LTSDK *)lt_shareInstance;

/**
 登录
 */
- (void)lt_login;

/**
 初始化sdk
 
 @param playId (29游参数表中gameId)
 @param playKey (29游参数表中秘钥key)
 @param canal channel (29游参数表中渠道ID)
 @param completion 处理回调
 */
+ (void)lt_initWithPlayId:(NSString *)playId withPlayKey:(NSString *)playKey withCanal:(NSString *)canal completion:(completionBlock)completion;

/**
 获取用户凭证 uuid

 @param block {
                     mes = "\U767b\U5f55\U9a8c\U8bc1\U6210\U529f",
                     uid = 466732;     
                     }
 */
+ (void)lt_getUidWithResult:(resultBlock)block;

/**
 上传游戏信息（必须先初始化完成调用）
 
 @param roleId 角色ID
 @param roleName 角色名称
 @param roleLevel 等级
 @param serverId 区服ID
 @param serverName 区服名称
 */
+ (void)lt_upGameInfoWithRoleId:(NSString *)roleId roleName:(NSString*)roleName roleLevel:(NSString*)roleLevel serverId:(NSString*)serverId serverName:(NSString*)serverName;

/**
 购买商品
 
 @param productId 商品id
 @param roleId 角色id
 @param serverId 区服id
 @param cpInfo 自定义字段，穿透参数，服务器回调时会返回去,可为空
 */
+ (void)lt_productWithProductId:(NSString *)productId roleId:(NSString *)roleId serverId:(NSString *)serverId cpInfo:(NSString *)cpInfo;

/**  获取playId */
+ (NSString *)playId;
/** 获取playKey */
+ (NSString *)playKey;
/** 获取canal,渠道号 */
+ (NSString *)canal;
/** 获取sdk版本号 */
+ (NSString *)sdkVersion;
/** 是否打印请求参数 */
+ (void)setIsShowParameterLog:(BOOL)isShow;

@end
