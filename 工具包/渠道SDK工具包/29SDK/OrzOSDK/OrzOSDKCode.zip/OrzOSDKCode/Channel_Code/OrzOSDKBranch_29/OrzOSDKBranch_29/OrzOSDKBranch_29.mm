

#import "OrzOSDKBranch_29.h"

@implementation OrzOSDKBranch_29


-(NSString *)getOrzOSDKChannelSdkVersion{
    return @"1.0.6";
}

-(void)doOrzOSDKChannelInit{
    NSLog(@"OrzOSDKBranch_ErJiu doChannelInit  !");
    NSDictionary *dict = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"OrzOSDKParams"];
    NSDictionary *channel_config = [dict objectForKey:@"ChannelParams"];
    
    self.appid_29 = [[NSString alloc] initWithFormat:@"%@", [channel_config objectForKey:@"Branch_29_gameid"]];
    self.secret_29 = [[NSString alloc] initWithFormat:@"%@", [channel_config objectForKey:@"Branch_29_gamekey"]];
    self.igvaAPP_29 = [[NSString alloc] initWithFormat:@"%@", [channel_config objectForKey:@"Branch_29_igvaAPP"]];
    
    NSLog(@"appid_29 = %@", self.appid_29);
    NSLog(@"secret_29 = %@", self.secret_29);
    NSLog(@"igvaAPP_29 = %@", self.igvaAPP_29);
    
    [[NGSDK getInstance]initWithGameId:self.appid_29 andGameKey:self.secret_29 andSecret:self.igvaAPP_29];
    
    [self.delegate channel_initOrzOSDKSuccess:@{@"code":@"1",@"msg":@"success"}];
    
}

-(void)doOrzOSDKChannelLogin{
    [[NGSDK getInstance]loginWithDelegate:self];
    
    NSLog(@"OrzOSDKBranch_29 doChannelLogin");
}

-(void)doOrzOSDKChannelSwitchAccount{
    [self.delegate channel_logoutOrzOSDKSuccess:@{@"code":@"1",@"msg":@"switch account success"}];
}


-(void)doOrzOSDKChannelLogout{
    [self.delegate channel_logoutOrzOSDKSuccess:@{@"code":@"1",@"msg":@"logout success"}];
}

-(void)doChannelshowOrzOSDKGameCenter{
    
}

-(void)doChannelshowOrzOSDKFloatView{
    
}

//登录回调
- (void)loginCallBack:(NSDictionary *)dict{
    
    NSLog(@"登录回调:%@",dict);
    //上传就是信息
    //    [[NGSDK getInstance] ngInitGameInfoWithRoleId:@"110" roleName:@"神剑无双" roleLevel:@"12" zoneId:@"110" zoneName:@"三分天下" dataType:@"1" ext:@""];
    [self.delegate channel_loginOrzOSDKSuccess:@{@"channel_uid":@"",
                                                       @"channel_username":@"",
                                                       @"channel_token":[[NGSDK getInstance] getLoginToken],
                                                       @"channel_deviceid":@"29Sdk"}];
}
//支付回调
- (void)iapResultCallBack:(NSDictionary *)dict{
    
    NSLog(@"支付回调：%@",dict);
    
    if([[dict objectForKey:@"payState"] integerValue] == 1){
        //支付成功
        NSLog(@"支付成功");
        [self.delegate channel_RegchargOrzOSDKSuccess:@{@"code":@"0",@"msg":@"已完成"}];
    }else{
        //支付失败
        NSLog(@"支付失败");
        [self.delegate channel_RegchargOrzOSDKFail:@{@"code":@"-2",@"msg":@"已取消"}];
    }
}

-(void)doChannelhideOrzOSDKFloatView{
    
}

-(void)doOrzOSDKChannelRegcharg:(NSDictionary *)params{
    int flag = 0;
    if([[OrzOSDKUtils getSharedInstance] getOrzOSDKInfoPlist_Landscape] == YES){
        flag = 1;
    }else{
        flag = 0;
    }
    NSLog(@"flag = %d", flag);
    //- (void)yapWithToken:(NSString *)token andProductId:(NSString *)productId andtTransferInfo:(NSString *)transInfo andScreenType:(NSInteger )type andRoleId:(NSString *)roleId andZoneId:(NSString *)zoneId;
    
    /**
     IAP
     
     @param token 登录token
     @param productId 商品ID
     @param transInfo 透传参数
     @param zoneId 服务器ID
     @param roleId 角色ID
     @param type 横竖屏  （0 竖屏，1 横屏）
     */
    [[NGSDK getInstance]yapWithToken:[[NGSDK getInstance] getLoginToken] andProductId:[params objectForKey:OrzOSDK_IOS_PRODUCT_ID] andtTransferInfo:[params objectForKey:OrzOSDK_IOS_ORDERID] andScreenType:1 andRoleId:self.roleid andZoneId:self.serverid];
}

-(void)doOrzOSDKChannelRealNameRegister:(int)flag{
    
}

-(void)doOrzOSDKChannelSendGameData:(NSString *)dataPoint data:(NSDictionary *)data{
    self.serverid = [[NSString alloc] initWithFormat:@"%@", [data objectForKey:OrzOSDK_SERVER_ID]];
    self.roleid = [[NSString alloc] initWithFormat:@"%@", [data objectForKey:OrzOSDK_ROLE_ID]];
    
    if([dataPoint isEqualToString:OrzOSDK_SUBMIT_ROLE_ENTERSERVER]){
        [[NGSDK getInstance] ngInitGameInfoWithRoleId:[data objectForKey:OrzOSDK_ROLE_ID] roleName:[data objectForKey:OrzOSDK_ROLE_NAME] roleLevel:[data objectForKey:OrzOSDK_ROLE_LEVEL] zoneId:[data objectForKey:OrzOSDK_SERVER_ID] zoneName:[data objectForKey:OrzOSDK_SERVER_NAME] dataType:@"1" ext:@""];
    }
}

-(BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions{
    return TRUE;
}

- (void)applicationWillResignActive:(UIApplication *)application{
    
}
- (void)applicationDidEnterBackground:(UIApplication *)application{
    
}
- (void)applicationWillEnterForeground:(UIApplication *)application{
    
}
- (void)applicationDidBecomeActive:(UIApplication *)application{
    
}
- (void)applicationWillTerminate:(UIApplication *)application{
    
}

-(BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url{
    return TRUE;
}

-(BOOL)application:(UIApplication *)application openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options{
    return TRUE;
}

-(BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation{
    return TRUE;
}

-(BOOL)application:(UIApplication *)application continueUserActivity:(NSUserActivity *)userActivity restorationHandler:(void(^)(NSArray * __nullable restorableObjects))restorationHandler{
    return TRUE;
}


@end
