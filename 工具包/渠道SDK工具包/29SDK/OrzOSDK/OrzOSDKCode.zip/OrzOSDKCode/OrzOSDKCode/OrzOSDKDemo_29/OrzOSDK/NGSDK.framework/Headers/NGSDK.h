//
//  NGSDK.h
//  BYDEMO
//
//  Created by beiyou on 2017/12/6.
//  Copyright © 2017年 WE. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^ResultInfo)(NSDictionary* data);

@protocol NGSDKDelegate <NSObject>
@required
- (void)loginCallBack:(NSDictionary *)dict;
- (void)iapResultCallBack:(NSDictionary *)dict;
@end

@interface NGSDK : NSObject
@property (nonatomic,assign) id<NGSDKDelegate>delegate;

+(NGSDK*)getInstance;

//调用登录
- (void)loginWithDelegate:(id)NGSDKDelete;

/**
初始化
 
 @param gameId 游戏ID
 @param gameKey 游戏Key
 @param secret 秘钥
 */
- (void)initWithGameId:(NSString *)gameId andGameKey:(NSString *)gameKey andSecret:(NSString *)secret;



/**
 角色信息上传
 
 @param roleId 角色ID
 @param roleName 角色名字
 @param roleLevel 角色等级
 @param zoneId 服务器ID
 @param zoneName 服务器名字
 @param dataType 类型 默认 1 （进入游戏）
 @param ext 预留字段
 */
-(void)ngInitGameInfoWithRoleId:(NSString*)roleId roleName:(NSString*)roleName roleLevel:(NSString*)roleLevel zoneId:(NSString*)zoneId  zoneName:(NSString*)zoneName dataType:(NSString*)dataType  ext:(NSString*)ext;

/**
IAP
 
 @param token 登录token
 @param productId 商品ID
 @param transInfo 透传参数
 @param zoneId 服务器ID
 @param roleId 角色ID
 @param type 横竖屏  （0 竖屏，1 横屏）
 */
- (void)yapWithToken:(NSString *)token andProductId:(NSString *)productId andtTransferInfo:(NSString *)transInfo andScreenType:(NSInteger )type andRoleId:(NSString *)roleId andZoneId:(NSString *)zoneId;
// 获取票据
- (NSString *)getLoginToken;
@end


