
#import <Foundation/Foundation.h>
#import "SourceSdk_const_def.h"
#import <UIKit/UIKit.h>

@interface SourceSdk : NSObject

+(void)initSource:(Boolean)isLandscape
     Source_Appid:(NSString *)Source_Appid
    Source_Appkey:(NSString *)Source_Appkey
   Source_Channel:(NSString *)Source_Channel
 Source_Appsecret:(NSString *)Source_Appsecret
       Source_Gid:(NSString *)Source_Gid
  Source_RYAppkey:(NSString *)Source_RYAppkey
    success:(Source_SUCCESS_Callback)success
     failed:(Source_FAILED_Callback)failed;

+(void)destroySource;

+(void)loginSource:(UIView*)view
   landscape:(Boolean)isLandscape
     success:(Source_SUCCESS_Callback)success
      failed:(Source_FAILED_Callback)failed;

+(void)logoutSource:(UIView*)view
      success:(Source_SUCCESS_Callback)success
       failed:(Source_FAILED_Callback)failed;

+(void)executeSource:(UIViewController *)controller
     landscape:(Boolean)isLandscape
;

+(void)hideFloatSource;

+(void)showSourceShiMingRenZhengView:(NSString *)accessToken callback:(Source_COMMON_BLOCK)callback;

+(NSString *)getImei;

+(NSString *)getChannel;
//启动统计接口
+(void)loadingSource:(Source_SUCCESS_Callback)success
        failed:(Source_FAILED_Callback)failed;
//激活帐户
+(void)active;

//创建角色
+(void)createRoleSource:(NSString *) serverid
       userId:(NSString*) userId
           roleId:(NSString *)roleId
        roleLevel:(NSString *)roleLevel
      success:(Source_SUCCESS_Callback)success
       failed:(Source_FAILED_Callback)failed;

+(void)loginRoleSource:(NSString *) serverid
       userId:(NSString*) userId
          roleId:(NSString *)roleId
       roleLevel:(NSString *)roleLevel
      success:(Source_SUCCESS_Callback)success
       failed:(Source_FAILED_Callback)failed;

+(void)startPSourcey:(UIViewController*)context
 landscape:(Boolean)isLandscape
    params:(NSDictionary*)params
   success:(Source_SUCCESS_Callback)success
    failed:(Source_FAILED_Callback)failed;



+(void)logout:(NSString *) serverid
      userId:(NSString*) userId
     success:(Source_SUCCESS_Callback)success
      failed:(Source_FAILED_Callback)failed;

+(void)level:(NSString*) level
    serverid:(NSString *) serverid
         userId:(NSString*) userId
     role_id:(NSString*)roleid
        success:(Source_SUCCESS_Callback)success
         failed:(Source_FAILED_Callback)failed;

+(void)error:(NSString *)log
     success:(Source_SUCCESS_Callback)success
      failed:(Source_FAILED_Callback)failed;

+(void)checkSourceUpdate:(UIView*)context
           success:(Source_SUCCESS_Callback)success
            failed:(Source_FAILED_Callback)failed
         landscape:(Boolean) landspace;
@end
