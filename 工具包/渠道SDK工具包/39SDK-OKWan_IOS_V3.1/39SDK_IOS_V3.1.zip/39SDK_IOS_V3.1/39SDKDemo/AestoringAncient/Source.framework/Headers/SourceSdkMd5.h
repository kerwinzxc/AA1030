

#import <Foundation/Foundation.h>

@interface SourceSdkMd5

+(NSString*)md5:(NSString*)md5HexDigest;


@end
