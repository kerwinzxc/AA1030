
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "SourceSdk_const_def.h"





@interface SourceCommonApi : NSObject

@property(nonatomic, strong) NSString * realURL;


- (NSURL *)getUrlSourceWithController:(NSString *)controller andParamDictionary:(NSDictionary *)paramDictionary;

-(void)getSourceHistoryUserNameByImei:(NSString *)imei
                           idfa:(NSString *)idfa
                completionBlock:(Source_VSD_BLOCK)completionBlock
                    failedBlock:(Source_VE_BLOCK)failedBlock;

//手机是否注册过
-(void)checkSourcePhoneRegist:(NSString*)phone
        completionBlock:(Source_VSD_BLOCK)completionBlock
            failedBlock:(Source_VE_BLOCK)failedBlock;

//手机注册接口
-(void)phoneSourceRegist:(NSString*)phone
          password:(NSString*)password
        verifyCode:(NSString*)verifyCode
   completionBlock:(Source_VSD_BLOCK)completionBlock
       failedBlock:(Source_VE_BLOCK)failedBlock;

//手机注册发送验证码接口
-(void)phoneSourceRegistVerify:(NSString*)phone
   completionBlock:(Source_VSD_BLOCK)completionBlock
       failedBlock:(Source_VE_BLOCK)failedBlock;


//手机登录接口
-(void)phoneSourceLogin:(NSString*)phone
               password:(NSString*)password
  completionBlock:(Source_VSD_BLOCK)completionBlock
      failedBlock:(Source_VE_BLOCK)failedBlock;


-(void)checkSourceUpdate:(NSString*)client_id
          bundleId:(NSString*)bundleId
           version:(NSString*)version
            device:(NSString*)device
        sourceCode:(NSString*)sourceCode
   completionBlock:(Source_VSD_BLOCK)completionBlock
       failedBlock:(Source_VE_BLOCK)failedBlock;

- (void)Sourceinstall:(NSString*)appId
   imeiOfDevice:(NSString*)imei
        channel:(NSString*)channel
          model:(NSString*)model
             os:(NSString*)os
completionBlock:(Source_VSD_BLOCK)completionBlock
    failedBlock:(Source_VE_BLOCK)failedBlock;



- (void)newadSourceinstall:dataEncode
                sign:sign
  completionBlock:(Source_VSD_BLOCK)completionBlock
      failedBlock:(Source_VE_BLOCK)failedBlock;


- (void)normalSourceRegister:(NSString*)username
              password:(NSString*)password
       completionBlock:(Source_VSD_BLOCK)completionBlock
           failedBlock:(Source_VE_BLOCK)failedBlock;

- (void)login:(NSString*)username
     password:(NSString*)password
completionBlock:(Source_VSD_BLOCK)completionBlock
  failedBlock:(Source_VE_BLOCK)failedBlock;

- (void)getSourceAccessToken:(NSString*)code
completionBlock:(Source_VSD_BLOCK)completionBlock
  failedBlock:(Source_VE_BLOCK)failedBlock;

- (void)getSourceUserId:(NSString*)accesstoken
       completionBlock:(Source_VSD_BLOCK)completionBlock
           failedBlock:(Source_VE_BLOCK)failedBlock;

- (void)logout:(NSString*)username
completionBlock:(Source_VSD_BLOCK)completionBlock
   failedBlock:(Source_VE_BLOCK)failedBlock;

- (void)createOrSourceder:(NSString*)accessToken
             userId:(NSString*)userId
        productName:(NSString*)productName
          productId:(NSString*)productId
            account:(NSInteger)account
         appOrderId:(NSString*)appOrderId
            appName:(NSString*)appName
           clientId:(NSString*)clientId
            gateway:(NSInteger)gateway
            channel:(NSString*)channel
          orderType:(NSString*)orderType
              extra:(NSString*)extra
             extend:(NSString*)extend
               sign:(NSString*)sign
    completionBlock:(Source_VSD_BLOCK)completionBlock
        failedBlock:(Source_VE_BLOCK)failedBlock;

- (void)checkSourceMail:(NSString*)accessToken
  completionBlock:(Source_VSD_BLOCK)completionBlock
      failedBlock:(Source_VE_BLOCK)failedBlock;

- (void)bindSourceMail:(NSString*)accessToken
           email:(NSString*)email
 completionBlock:(Source_VSD_BLOCK)completionBlock
     failedBlock:(Source_VE_BLOCK)failedBlock;

- (void)checkSourcePhone:(NSString*)accessToken
   completionBlock:(Source_VSD_BLOCK)completionBlock
       failedBlock:(Source_VE_BLOCK)failedBlock;

- (void)bindSourcePhone:(NSString*)accessToken
            phone:(NSString*)phone
  completionBlock:(Source_VSD_BLOCK)completionBlock
      failedBlock:(Source_VE_BLOCK)failedBlock;

- (void)checkSourceIdentify:(NSString*)accessToken
  completionBlock:(Source_VSD_BLOCK)completionBlock
      failedBlock:(Source_VE_BLOCK)failedBlock;

- (void)startSourceIdentify:(NSString*)accessToken
                 name:(NSString*)name
       identifyNumber:(NSString*)identifyNumber
      completionBlock:(Source_VSD_BLOCK)completionBlock
          failedBlock:(Source_VE_BLOCK)failedBlock;



- (void)confirmSourcePhone:(NSString*)accessToken
              verify:(NSString*)verify
     completionBlock:(Source_VSD_BLOCK)completionBlock
         failedBlock:(Source_VE_BLOCK)failedBlock;

- (void)changeSourcePasswordByPhone:(NSString*)username
              completionBlock:(Source_VSD_BLOCK)completionBlock
                  failedBlock:(Source_VE_BLOCK)failedBlock;

- (void)confirmchangeSourcePasswordByPhone:(NSString*)username
                            password:(NSString*)password
                              verify:(NSString*)verify
                     completionBlock:(Source_VSD_BLOCK)completionBlock
                         failedBlock:(Source_VE_BLOCK)failedBlock;




- (void)fastSourceRegister:(Source_VSD_BLOCK)completionBlock
         failedBlock:(Source_VE_BLOCK)failedBlock;


+(SourceCommonApi*)sharedInstance;

-(void)changeSourcePasswordWithToken:(NSString *)accessToken
                   oldPassword:(NSString *)oldPassword
                   newPassword:(NSString *)newPassword
               completionBlock:(Source_VSD_BLOCK)completionBlock
                   failedBlock:(Source_VE_BLOCK)failedBlock;



-(void)getSourceSupport:(NSString *)appId
        onSuccess:(Source_VSD_BLOCK)successBlock
         onFailed:(Source_VE_BLOCK)failedBlock;


-(void)loadingSource:(NSMutableDictionary*) param
 completionBlock:(Source_VSD_BLOCK)completionBlock
    failedBlock:(Source_VE_BLOCK)failedBlock;



-(void)createSource:(NSMutableDictionary*) param
completionBlock:(Source_VSD_BLOCK)completionBlock
  failedBlock:(Source_VE_BLOCK)failedBlock;



-(void)login:(NSMutableDictionary*) param
completionBlock:(Source_VSD_BLOCK)completionBlock
  failedBlock:(Source_VE_BLOCK)failedBlock;


-(void)loginSourceout:(NSMutableDictionary*) param
completionBlock:(Source_VSD_BLOCK)completionBlock
 failedBlock:(Source_VE_BLOCK)failedBlock;

-(void)level:(NSMutableDictionary*) param
completionBlock:(Source_VSD_BLOCK)completionBlock
    failedBlock:(Source_VE_BLOCK)failedBlock;

-(void)erroSource:(NSMutableDictionary*) param
completionBlock:(Source_VSD_BLOCK)completionBlock
 failedBlock:(Source_VE_BLOCK)failedBlock;

-(void)bindSourceRegister:(NSString*) username
           password:(NSString*)password
       bindUsername:(NSString*) bindUsername
    completionBlock:(Source_VSD_BLOCK)completionBlock
        failedBlock:(Source_VE_BLOCK)failedBlock;


+(void) showSourceToast:(UIView*) view text:(NSString*) message;

- (void)changeSourcePasswordByEmail:(NSString*)username
              completionBlock:(Source_VSD_BLOCK)completionBlock
                  failedBlock:(Source_VE_BLOCK)failedBlock;

- (void)confirmSourceChangePasswordByEmail:(NSString*)username
                            password:(NSString*)password
                              verify:(NSString*)verify
                     completionBlock:(Source_VSD_BLOCK)completionBlock
                         failedBlock:(Source_VE_BLOCK)failedBlock;

-(void)checkPSourceyTypeUrl:(Source_VSD_BLOCK)completionBlock
             failedBlock:(Source_VE_BLOCK)failedBlock;

-(void)SourceSdkPyCheck:(NSString *)orderId
              description:(NSString *)description
     completionBlock:(Source_VSD_BLOCK)completionBlock
              failedBlock:(Source_VE_BLOCK)failedBlock;
@end
