

#import <Foundation/Foundation.h>
#import "SourceSdk_const_def.h"

@interface SourceRPC : NSObject



+ (void)requestPostSourceUrl:(NSURL *)url
       bodyDictionary:(NSDictionary *)bodyDictionary
      completionBlock:(Source_VSD_BLOCK)completionBlock
          failedBlock:(Source_VE_BLOCK)failedBlock;

@end
