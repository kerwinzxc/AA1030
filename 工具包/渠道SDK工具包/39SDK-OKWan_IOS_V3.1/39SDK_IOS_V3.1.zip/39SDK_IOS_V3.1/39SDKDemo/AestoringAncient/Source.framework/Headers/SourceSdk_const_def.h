
//正式服务器

#define Source_AD_API_SECRET @"42l$lo4f%24#ldfHjR"



#define Source_SDK_VERSION @"V3.0.2"




#define Source_APPID @"Source_APPID"
#define Source_APPKEY @"Source_APPKEY"
#define Source_APPPRIVATEKEY @"Source_APPPRIVATEKEY"
#define Source_APPSECRET @"Source_APPSECRET"
#define Source_AD_GID @"Source_AD_GID"
#define Source_AD_ADID @"Source_AD_ADID"
#define Source_CHANNEL @"Source_CHANNEL"
#define Source_IMEI @"Source_IMEI"

#define SJYX_IDFV @"SJYX_IDFV"

#define Source_PROTOCOL_CODE @"type"
#define Source_PROTOCOL_BINDPHONE @"phone"
#define Source_PROTOCOL_IDENTITY @"identity"
#define Source_PROTOCOL_ACCESSTOKEN @"access_token"
#define Source_PROTOCOL_PRODUCT_NAME @"product_name"
#define Source_PROTOCOL_PRODUCT_ID @"product_id"
#define Source_PROTOCOL_ACCOUNT @"account"
#define Source_PROTOCOL_APP_NAME @"app_name"
#define Source_PROTOCOL_USER_ID @"user_id"
#define Source_PROTOCOL_ROLE_ID @"role_id"
#define Source_PROTOCOL_ROLE_LEVEL @"role_level"
#define Source_PROTOCOL_APP_ORDER_ID @"app_order_id"
#define Source_PROTOCOL_GATEWAY @"gateway"
#define Source_PROTOCOL_EXTEND_INFO @"extend_info"
#define Source_PROTOCOL_XXX_URL @"XXX_url"


#define Source_NOTIFICATION_PY_FINISH @"py_finish"


typedef void(^Source_SUCCESS_Callback)(NSString *);
typedef void(^Source_RV_Complete_Callback)(NSString *, NSString*);
typedef void(^Source_FAILED_Callback)(int);
typedef void(^Source_VE_BLOCK)(NSError *);
typedef void(^Source_VSD_BLOCK)(NSDictionary *, NSDictionary *);

typedef void(^Source_ORDER_BLOCK)(NSString *);

typedef void(^Source_COMMON_BLOCK)(NSString *);

