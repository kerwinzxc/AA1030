

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "AestoringAncientUtils.h"



@protocol AestoringAncientDelegate <NSObject>

-(void)initAestoringAncientSuccess:(NSDictionary *)result;

-(void)initAestoringAncientFail:(NSDictionary *)result;

-(void)loginAestoringAncientSuccess:(NSDictionary *)result;

-(void)loginAestoringAncientFail:(NSDictionary *)result;

-(void)logoutAestoringAncientSuccess:(NSDictionary *)result;

-(void)logoutAestoringAncientFail:(NSDictionary *)result;

-(void)RegchargAestoringAncientSuccess:(NSDictionary *)result;

-(void)RegchargAestoringAncientFail:(NSDictionary *)result;

-(void)openAestoringAncientUserCenter;
-(void)closeAestoringAncientUserCenter;

@end


@interface AestoringAncient : NSObject<UIAlertViewDelegate>

@property (strong, nonatomic) id<AestoringAncientDelegate> AestoringAncientDelegate;

@property (nonatomic) Boolean AestoringAncientnetWorkIsOK;



+(AestoringAncient*)getSharedInstance;

-(void)initAestoringAncient;

-(void)startAestoringAncientLogin;

-(void)startAestoringAncientSwitchAccount;

-(void)startAestoringAncientLogout;

-(void)showAestoringAncientGameCenter;

-(void)showAestoringAncientFloatView;

-(void)hideAestoringAncientFloatView;

-(void)startAestoringAncientRegcharg:(NSDictionary *)params;

-(void)sendAestoringAncientData:(NSString *)dataPoint data:(NSDictionary *)data;

-(BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions;
- (void)applicationWillResignActive:(UIApplication *)application;
- (void)applicationDidEnterBackground:(UIApplication *)application;
- (void)applicationWillEnterForeground:(UIApplication *)application;
- (void)applicationDidBecomeActive:(UIApplication *)application;
- (void)applicationWillTerminate:(UIApplication *)application;

-(BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url;
-(BOOL)application:(UIApplication *)application openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options;
-(BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation;

-(BOOL)application:(UIApplication *)application continueUserActivity:(NSUserActivity *)userActivity restorationHandler:(void(^)(NSArray * __nullable restorableObjects))restorationHandler;


- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken;
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo;
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler;

@end



