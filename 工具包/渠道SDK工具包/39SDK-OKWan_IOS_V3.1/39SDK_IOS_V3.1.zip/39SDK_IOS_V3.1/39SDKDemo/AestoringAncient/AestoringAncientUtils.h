

#import <UIKit/UIKit.h>
#import <sys/utsname.h>
#import <AdSupport/ASIdentifierManager.h>
#import <Foundation/Foundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
#import <CoreTelephony/CTCarrier.h>
#import <Security/Security.h>
#import <CommonCrypto/CommonDigest.h>



#define AestoringAncient_SDK_VERSION @"3.1"

#define AestoringAncient_KEYCHAIN_IDFV @"AestoringAncient_KEYCHAIN_IDFV"
#define AestoringAncient_KEYCHAIN_UUID @"AestoringAncient_KEYCHAIN_UUID"



typedef void (^AestoringAncientRequestCallback)(NSURLResponse* response, id data, NSError* connectionError);

typedef void (^AestoringAncientInitCallback)(NSDictionary* result);
typedef void (^AestoringAncientLoginCallback)(NSDictionary* result);
typedef void (^AestoringAncientLogoutCallback)(NSDictionary* result);
typedef void (^AestoringAncientCheckUpdateCallback)(NSDictionary* result);
typedef void (^AestoringAncientCreateOderCallback)(NSDictionary* result);
typedef void (^AestoringAncientXXXCloseCallback)(NSDictionary* result);


#define AestoringAncient_SUBMIT_CHOOSE_SERVER      @"AestoringAncient_SUBMIT_CHOOSE_SERVER"
#define AestoringAncient_SUBMIT_CHOOSE_ROLE        @"AestoringAncient_SUBMIT_CHOOSE_ROLE"
#define AestoringAncient_SUBMIT_ROLE_CREATE        @"AestoringAncient_SUBMIT_ROLE_CREATE"
#define AestoringAncient_SUBMIT_ROLE_LEVELUP       @"AestoringAncient_SUBMIT_ROLE_LEVELUP"
#define AestoringAncient_SUBMIT_ROLE_ENTERSERVER   @"AestoringAncient_SUBMIT_ROLE_ENTERSERVER"



#define AestoringAncient_ROLE_ID            @"AestoringAncient_ROLE_ID"
#define AestoringAncient_ROLE_LEVEL         @"AestoringAncient_ROLE_LEVEL"
#define AestoringAncient_ROLE_NAME          @"AestoringAncient_ROLE_NAME"
#define AestoringAncient_ROLE_CREATE_TIME   @"AestoringAncient_ROLE_CREATE_TIME"
#define AestoringAncient_SERVER_ID          @"AestoringAncient_SERVER_ID"
#define AestoringAncient_SERVER_NAME        @"AestoringAncient_SERVER_NAME"



#define AestoringAncient_IOS_PRODUCT_NAME   @"AestoringAncient_IOS_PRODUCT_NAME"
#define AestoringAncient_IOS_PRODUCT_ID     @"AestoringAncient_IOS_PRODUCT_ID"
#define AestoringAncient_IOS_CP_ORDERID     @"AestoringAncient_IOS_CP_ORDERID"
#define AestoringAncient_IOS_PRODUCT_DESC   @"AestoringAncient_IOS_PRODUCT_DESC"
#define AestoringAncient_IOS_PRODUCT_PRICE  @"AestoringAncient_IOS_PRODUCT_PRICE"
#define AestoringAncient_IOS_GOODS_NUM      @"AestoringAncient_IOS_GOODS_NUM"
#define AestoringAncient_IOS_ORDERID        @"AestoringAncient_IOS_ORDERID"
#define AestoringAncient_IOS_EXTRA          @"AestoringAncient_IOS_EXTRA"
#define AestoringAncient_IOS_ROLE_ID        @"AestoringAncient_IOS_ROLE_ID"
#define AestoringAncient_IOS_ROLE_NAME      @"AestoringAncient_IOS_ROLE_NAME"
#define AestoringAncient_IOS_ROLE_LEVEL     @"AestoringAncient_IOS_ROLE_LEVEL"
#define AestoringAncient_IOS_SERVER_ID      @"AestoringAncient_IOS_SERVER_ID"
#define AestoringAncient_IOS_SERVER_NAME    @"AestoringAncient_IOS_SERVER_NAME"




#define INIT_ERROR_NETWORK_ERROR @"请检查网络连接"





@interface AestoringAncientUtils : NSObject

+(AestoringAncientUtils*)getSharedInstance;

-(void) showAestoringAncientToastMsg:(NSString *)text view:(UIView *)view;

-(NSString *)getAestoringAncientNetIsp;//获取运营商信息
-(NSString *)getAestoringAncientNetworktype;//获取网络类型
-(NSString *)getAestoringAncientSystemVersion;//获取手机系统版本
-(NSString *)getAestoringAncientIdfa;//获取手机idfa
-(NSString *)getAestoringAncientIdfv;//获取手机idfv
-(NSString *)getAestoringAncientUUID;//获取手机getAestoringAncientUUID
-(NSString *)getAestoringAncientMac;//获取手机getAestoringAncientMac
-(NSString *)getAestoringAncientPhoneUserName;//获取手机别名
-(NSString *)getAestoringAncientDeviceName;//获取设备名称
-(NSString *)getAestoringAncientDeviceModel;//获取手机型号
-(NSString *)getAestoringAncientLocalPhoneModel;//获取地方型号（国际化区域名称）
-(NSString*)getAestoringAncientInstalledFlag;

-(NSString *)getAestoringAncientBundleId;
-(NSString *)getAestoringAncientAppName;
-(NSString *)getAestoringAncientAppVersion;
-(NSString *)getAestoringAncientAppBuildVersion;
-(NSString *)getAestoringAncientVersion;
-(NSString *)getAestoringAncientChannelSdkVersion;

-(NSString *)getAestoringAncientInfoPlist_PackageId;
-(Boolean)getAestoringAncientInfoPlist_Landscape;


-(void)setAestoringAncientUserInfo:(NSString*) username
            userid:(NSString*) userid
          password:(NSString*) password
             token:(NSString*) token;
-(NSString *)getAestoringAncientUserId;
-(NSString *)getChannelUserId;

-(NSString *)AestoringAncient_md5:(NSString *)str;

-(void)postAestoringAncientActiveData;
-(void)postAestoringAncientGameData:(NSString *)dataPoint data:(NSDictionary *)data;
-(void)requestAestoringAncientNotice:(AestoringAncientRequestCallback)result;
-(void)requestAestoringAncientServerStatus:(AestoringAncientInitCallback)result;
-(void)getAestoringAncientLoginInfo:(NSDictionary *)dic result:(AestoringAncientLoginCallback)result;
-(void)doAestoringAncientLogout:(AestoringAncientLogoutCallback)result;
-(void)doAestoringAncientCheckUpdate:(AestoringAncientCheckUpdateCallback)result;
-(void)doAestoringAncientCreateOder:(NSDictionary *)param createOderCB:(AestoringAncientCreateOderCallback)createOderCB;
-(void)sendAestoringAncientHeartData;
-(void)doAestoringAncientPostAction:(NSDictionary *)httpParams toAestoringAncientServer:(NSString *)requestPath responseHandler:(AestoringAncientRequestCallback)handler showProgess:(Boolean)showprogress;

@end


