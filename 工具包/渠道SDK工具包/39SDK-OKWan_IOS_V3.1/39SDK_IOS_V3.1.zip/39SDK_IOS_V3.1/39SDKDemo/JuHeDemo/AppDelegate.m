

#import "AppDelegate.h"
#import "AestoringAncient.h"
#import "ViewController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
//    [[AestoringAncient getSharedInstance] getAestoringAncientHKeJiFlag:^(BOOL flag){
//        self.nowStatus = flag;
//        if(flag == NO){
//            //此处填入原来游戏的viercontroller
//            self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
//            self.window.backgroundColor = [UIColor whiteColor];
//            ViewController *controller = [[ViewController alloc] init];
//            self.window.rootViewController = controller;
//            [self.window makeKeyAndVisible];
//        }else{
//            //此处可直接复制
//            self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
//            self.window.backgroundColor = [UIColor whiteColor];
//            self.window.rootViewController = [[AestoringAncient getSharedInstance] showAestoringAncientHKeJiVC];
//            [self.window makeKeyAndVisible];
//
//        }
//
//    }];
    //此处填入原来游戏的viercontroller
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.backgroundColor = [UIColor whiteColor];
    ViewController *controller = [[ViewController alloc] init];
    self.window.rootViewController = controller;
    [self.window makeKeyAndVisible];

    
    [[AestoringAncient getSharedInstance] application:application didFinishLaunchingWithOptions:launchOptions];
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    [[AestoringAncient getSharedInstance] applicationWillResignActive:application];
    if(self.nowStatus == NO){
        //游戏逻辑
    }
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    [[AestoringAncient getSharedInstance] applicationDidEnterBackground:application];
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    [[AestoringAncient getSharedInstance] applicationWillEnterForeground:application];
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    [[AestoringAncient getSharedInstance] applicationDidBecomeActive:application];
}


- (void)applicationWillTerminate:(UIApplication *)application {
    [[AestoringAncient getSharedInstance] applicationWillTerminate:application];
}

-(BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url{
    return [[AestoringAncient getSharedInstance] application:application handleOpenURL:url];
}

-(BOOL)application:(UIApplication *)application openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options{
    return [[AestoringAncient getSharedInstance] application:application openURL:url options:options];
}

-(BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation{
    return [[AestoringAncient getSharedInstance] application:application openURL:url sourceApplication:sourceApplication annotation:annotation];
}

-(BOOL)application:(UIApplication *)application continueUserActivity:(NSUserActivity *)userActivity restorationHandler:(void(^)(NSArray * __nullable restorableObjects))restorationHandler{
    return [[AestoringAncient getSharedInstance] application:application continueUserActivity:userActivity restorationHandler:restorationHandler];
}

@end

