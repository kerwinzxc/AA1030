

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (nonatomic) Boolean bInitSuccess;

@end

