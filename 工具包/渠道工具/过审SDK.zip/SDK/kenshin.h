//
//  kenshin.h
//  kenshin
//
//  Created by Blazefire on 2017/9/28.
//  Copyright © 2017年 wang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface kenshin : NSObject

+ (void)initKenshin;

@end
