//
//  MiniGame.h
//  MiniGame
//
//  Created by xianpeng.liu on 2018/8/2.
//  Copyright © 2018 Little Tech. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MiniGame : NSObject

+(void)start:(int)argc andArgv:(char *[])argv;

@end
