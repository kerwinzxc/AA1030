//
//  AppDelegate.h
//  MiniGame
//
//  Created by xianpeng.liu on 2018/8/1.
//  Copyright © 2018 Little Tech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MiniAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

