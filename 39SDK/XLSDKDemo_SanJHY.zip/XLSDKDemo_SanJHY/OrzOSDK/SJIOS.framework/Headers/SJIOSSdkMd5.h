

#import <Foundation/Foundation.h>

@interface SJIOSSdkMd5

+(NSString*)md5:(NSString*)md5HexDigest;


@end
