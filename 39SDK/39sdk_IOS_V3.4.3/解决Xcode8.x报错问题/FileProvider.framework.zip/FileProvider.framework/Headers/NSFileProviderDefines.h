//
//  NSFileProviderDefines.h
//  FileProvider
//
//  Copyright © 2017 Apple Inc. All rights reserved.
//

// This file intentionally left blank.
